﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace waelsbookservice.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("books")]
    public class BooksController : ApiController
    {
        BooksModel _context = new BooksModel();
        // GET api/values
        [Route("Getbooks")]
        public IEnumerable<Book> Get()
        {
            return _context.Books.ToList();
        }


        [HttpGet]
        [Route("Getbook/{id:int}")]
        public Book Get(int id)
        {
            return _context.Books.FirstOrDefault(book => book.Id == id);
        }


        // POST api/values
        [Route("AddBook")]
        [HttpPost]
        public void Post([FromBody]Book book)
        {
            _context.Books.Attach(book);
            _context.Entry(book).State = EntityState.Added;
            _context.SaveChangesAsync();
        }

        // Put api/values
        [Route("ModifyBook")]
        [HttpPut]
        public void Put([FromBody]Book book)
        {
            _context.Books.Attach(book);
            _context.Entry(book).State = EntityState.Modified;
            _context.SaveChangesAsync();
        }

        // DELETE api/values/5
        [Route("DeleteBook/{id}")]
        [HttpDelete]
        public void DeleteBook(int id)
        {
            var book = _context.Books.FirstOrDefault(b => b.Id == id);
            _context.Entry(book).State = EntityState.Deleted;
            _context.SaveChangesAsync();
        }

        [Route("GetNextId")]
        [HttpGet]
        public int GetNextId()
        {
            return _context.Books.OrderByDescending(b => b.Id).FirstOrDefault().Id + 1;
        }
    }
}
